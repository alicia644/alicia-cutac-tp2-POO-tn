package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.entidades;

public class Auto extends Vehiculo {

    private int puertas;

    public Auto(String marca, String modelo, double precio, int puertas) {
        super(marca, modelo, precio);
        this.puertas = puertas;
    }

    @Override
    public String toString() {//El método toString devuelve una salida por consola personalizada del objeto.
        return "Marca: " + marca +  " // Modelo: " + modelo + " // Puertas: " + puertas + " // precio: $" + precioFormateado();
    }
}
