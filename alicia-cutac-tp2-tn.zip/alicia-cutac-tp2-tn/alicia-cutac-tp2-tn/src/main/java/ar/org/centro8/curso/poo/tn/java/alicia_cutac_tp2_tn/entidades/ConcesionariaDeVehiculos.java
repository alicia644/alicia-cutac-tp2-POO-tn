package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.entidades;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


public class ConcesionariaDeVehiculos { //Esta clase sirve para gestionar todos los métodos y acciones.
    List<Vehiculo> vehiculos = new ArrayList<>(); //Creación de una lista.  

    /*
     * Método que crea y agrega vehículos en la lista y los muestra por consola.
     */
    public void crearLista(){ 
        vehiculos.add(new Auto("Peugeot", "206", 200000, 4));
        vehiculos.add(new Moto("Honda", "Titan", 60000, 125));
        vehiculos.add(new Auto("Peugeot", "208", 250000, 5));
        vehiculos.add(new Moto("Yamaha", "YBR", 80500.50, 160));
        vehiculos.forEach(System.out::println);
    }
    /*
     * Método que compara los precios de los vehículos y devuelve el precio más alto.
     */
    public void maxPrecio(){ 
        System.out.println("\n=============================\n");

        System.out.print("Vehiculo más caro: ");
        Vehiculo max = vehiculos
                .stream() 
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println(max.getMarca() + " " + max.getModelo());
    }

     /*
     * Método que compara los precios y devuelve el precio más bajo.
     */
    public void minPrecio(){
        System.out.print("Vehiculo más barato: ");
        Vehiculo min = vehiculos
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get();
        System.out.println(min.getMarca() + " " + min.getModelo());
    }
    
     /*
     * Método que filtra los vehículos que en sus modelos contengan la letra pedida por parámetro.
     */
    public void modeloContieneLetra(String letra){
        System.out.print("Vehículo que contiene en el modelo la letra '" + letra + "': " );
        vehiculos
                .stream()
                .filter(v->v.getModelo().toLowerCase().contains(letra))
                .forEach(v->System.out.println( v.getMarca() + " " + v.getModelo() + " $" + v.precioFormateado()));
    }

    /*
     * Método que compara los precios y los ordena de forma descendente.
    */
    public void preciosOrdenadosDeMayorMenor(){
         System.out.println("\n=============================\n");

        System.out.println("Vehículos en orden de precios de mayor a menor: ");
        vehiculos
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(v->System.out.println(v.getMarca() + " "  +  v.getModelo()));
    }

    /**
     * Método que muestra los vehículos en el orden natural de la marca, modelo y precio.
     */
    public void ordenNaturalDeVehiculos(){ 
        System.out.println("\n=============================\n");
     
        System.out.println("Vehículos en orden natural:");
        vehiculos
                .stream()
                .sorted()
                .forEach(System.out::println);
    }

}
