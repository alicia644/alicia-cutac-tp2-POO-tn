package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.entidades;

public class Moto extends Vehiculo {
    private int cilindrada;

    public Moto(String marca, String modelo, double precio, int cilindrada) {
        super(marca, modelo, precio);
        this.cilindrada = cilindrada;
    }

    @Override
    public String toString() {
        return "Marca: " + marca +  " // Modelo: " + modelo + " // Cilindrada: " + cilindrada + "c // precio: $" + precioFormateado();
    }
}
