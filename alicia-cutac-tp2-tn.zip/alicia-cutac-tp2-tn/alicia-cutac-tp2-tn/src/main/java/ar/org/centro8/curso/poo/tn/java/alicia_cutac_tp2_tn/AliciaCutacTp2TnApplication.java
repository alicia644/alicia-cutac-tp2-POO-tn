package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AliciaCutacTp2TnApplication {

	public static void main(String[] args) {
		SpringApplication.run(AliciaCutacTp2TnApplication.class, args);
	}

}
