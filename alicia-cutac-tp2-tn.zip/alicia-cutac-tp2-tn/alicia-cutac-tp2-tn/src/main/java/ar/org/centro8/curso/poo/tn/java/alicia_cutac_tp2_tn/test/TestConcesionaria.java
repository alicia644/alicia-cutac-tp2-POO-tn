package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.test;

import ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.entidades.ConcesionariaDeVehiculos;

public class TestConcesionaria{
    public static void main(String[] args) {
        ConcesionariaDeVehiculos  concesionaria= new ConcesionariaDeVehiculos(); //Creación de un objeto de la clase+
        // concesionaria de vehículos a partir de la que se pueden ejecutar todos los métodos.
        concesionaria.crearLista();
        concesionaria.maxPrecio();
        concesionaria.minPrecio();
        concesionaria.modeloContieneLetra("y");
        concesionaria.preciosOrdenadosDeMayorMenor();
        concesionaria.ordenNaturalDeVehiculos();
    }

}
