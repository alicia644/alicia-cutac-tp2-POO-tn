package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.entidades;


import java.text.DecimalFormat;
import lombok.Getter;

@Getter

public abstract class Vehiculo  implements Comparable<Vehiculo> { //Abstract para que no se puedan crear objetos. 
    //Implements Comparable para ordenar los objetos comparando sus atributos.
    protected String marca;
    protected String modelo;
    protected double precio;
    DecimalFormat formatearPrecio= new DecimalFormat("###,000.00");


    public Vehiculo(String marca, String modelo, double precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.precio = precio;
    }
    public String precioFormateado(){ 
        return formatearPrecio.format(this.precio);
    }
    


    //protected permite acceder al atributo desde la clase hija para modificar el método toString.
    @Override
    public int compareTo(Vehiculo vehiculoPara) {
        String thisVehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
        String paraVehiculo = vehiculoPara.getMarca() + "," + vehiculoPara.getModelo() + "," + vehiculoPara.getPrecio();
        return thisVehiculo.compareTo(paraVehiculo); //CompareTo define el orden natural de la clase.
        //retorna -,= ó +, dependiendo si el atributo es menor,igual ó mayor 
    }
    
}    


