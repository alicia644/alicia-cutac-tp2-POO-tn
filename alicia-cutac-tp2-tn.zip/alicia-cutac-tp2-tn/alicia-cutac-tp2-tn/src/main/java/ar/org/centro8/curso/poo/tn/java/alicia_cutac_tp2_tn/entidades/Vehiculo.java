package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn.entidades;


import lombok.AllArgsConstructor;
import lombok.Getter;
@AllArgsConstructor
@Getter

public abstract class Vehiculo  implements Comparable<Vehiculo> { //Abstract para que no se puedan crear objetos. 
    //Implements Comparable para ordenar los objetos comparando sus atributos.
    protected String marca;
    protected String modelo;
    protected double precio;
    //protected permite acceder al atributo desde la clase hija para modificar el método toString.
    @Override
    public int compareTo(Vehiculo vehiculoPara) {
        String thisVehiculo = this.getMarca() + "," + this.getModelo() + "," + this.getPrecio();
        String paraVehiculo = vehiculoPara.getMarca() + "," + vehiculoPara.getModelo() + "," + vehiculoPara.getPrecio();
        return thisVehiculo.compareTo(paraVehiculo); //CompareTo define el orden natural de la clase.
        //retorna -,= ó +, dependiendo si el atributo es menor,igual ó mayor 
    }
    
}    


