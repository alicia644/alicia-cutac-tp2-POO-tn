package ar.org.centro8.curso.poo.tn.java.alicia_cutac_tp2_tn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AliciaCutacTp2TnApplicationTests {

	@Test
	void contextLoads() {
	}

}
